import os
import json
import requests
import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
from pyvis.network import Network

# Page Configuration
st.set_page_config(
    page_title="IntelTrace | Threat & Identity Intelligence",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1.0rem;
        color: #94A3B8;
        margin-bottom: 1.5rem;
    }
    .card-warning {
        background-color: #2D2305;
        border-left: 5px solid #F59E0B;
        padding: 1.2rem;
        border-radius: 8px;
        margin-bottom: 1rem;
        color: #FDE68A !important;
    }
    .card-warning h4 {
        color: #FBBF24 !important;
        margin-top: 0;
    }
    .card-warning ul {
        color: #FDE68A !important;
    }
</style>
""", unsafe_allow_html=True)

# Helper: Robust Field Extractor with fallback sequence
def get_entity_field(entity, *keys, default="Unknown"):
    for k in keys:
        val = entity.get(k)
        if val is not None and str(val).strip() != "":
            return val
    return default

# Helper: Platform Icon & Label Resolver
def resolve_platform(entity):
    platform_val = get_entity_field(entity, "platform", "source", "type", "service", default="")
    p = str(platform_val).lower()
    
    # Infer platform from handle/id if not explicitly set
    handle_val = str(get_entity_field(entity, "handle", "username", "name", "id", "entity_id")).lower()
    
    if "instagram" in p or "insta" in handle_val:
        return "📸 Instagram"
    elif "telegram" in p or "tg" in handle_val:
        return "✈️ Telegram"
    elif "twitter" in p or "x" in p:
        return "🐦 X / Twitter"
    elif "darknet" in p or "onion" in p or "market" in handle_val or "vendor" in handle_val:
        return "🧅 Darknet / Forum"
    elif "github" in p or "coder" in handle_val or "dev" in handle_val:
        return "🐙 GitHub / Dev"
    elif platform_val:
        return f"🌐 {str(platform_val).capitalize()}"
    else:
        return "🌐 Cyber Space"

# Helper: Favicon URL Generator
def get_favicon_url(domain):
    clean_domain = domain.replace("https://", "").replace("http://", "").split("/")[0]
    return f"https://www.google.com/s2/favicons?domain={clean_domain}&sz=64"

# Helper: Live Website Ping Status Tracker
def ping_website(url):
    target = url if url.startswith(("http://", "https://")) else "https://" + url
    try:
        response = requests.get(target, timeout=3)
        if response.status_code == 200:
            return "🟢 Live (200 OK)", f"{int(response.elapsed.total_seconds() * 1000)} ms", "Normal"
        else:
            return f"🟠 Active ({response.status_code})", f"{int(response.elapsed.total_seconds() * 1000)} ms", "Flagged"
    except Exception:
        return "🔴 Offline / Unreachable", "N/A", "High Risk / Suspicious"

# Data Loading Routine
@st.cache_data
def load_data():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    
    entities, links, observations = [], [], []
    
    if os.path.exists(os.path.join(data_dir, "entities.json")):
        with open(os.path.join(data_dir, "entities.json"), "r", encoding="utf-8") as f:
            entities = json.load(f)
            
    if os.path.exists(os.path.join(data_dir, "links.json")):
        with open(os.path.join(data_dir, "links.json"), "r", encoding="utf-8") as f:
            links = json.load(f)
            
    if os.path.exists(os.path.join(data_dir, "sample_observations.json")):
        with open(os.path.join(data_dir, "sample_observations.json"), "r", encoding="utf-8") as f:
            observations = json.load(f)
            
    return entities, links, observations

entities, links, observations = load_data()

# Header Section
st.markdown('<div class="main-header">🛡️ Digital Identity & Threat Monitor</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">An easy-to-use intelligence platform for tracking digital aliases, suspicious websites, and connected networks.</div>', unsafe_allow_html=True)

# Overview Metrics
col1, col2, col3, col4 = st.columns(4)
col1.metric(label="Tracked Entities / Users", value=len(entities), delta="Monitored")
col2.metric(label="Connected Links", value=len(links), delta="Active Network")
col3.metric(label="Logged Observations", value=len(observations))
col4.metric(label="System Status", value="Operational")

st.divider()

# Navigation Tabs
tab1, tab2, tab3, tab4 = st.tabs([
    "👤 Tracked Identities & Apps",
    "🌐 Website Demo & Live Tracker",
    "🕸️ Interactive Network Graph",
    "📊 Simple Threat Summary"
])

# TAB 1: IDENTITIES & APPS
with tab1:
    st.subheader("Monitored Accounts & Social Platforms")
    st.caption("Overview of tracked digital handles across various social media platforms and forums.")
    
    if entities:
        table_data = []
        for e in entities:
            # Fallback hierarchy: if 'handle' or 'username' missing, use 'id' or 'entity_id'
            entity_id = get_entity_field(e, "entity_id", "id", "uid", default="N/A")
            handle_val = get_entity_field(e, "handle", "username", "name", "alias", "entity_id", "id", default=entity_id)
            platform_val = resolve_platform(e)
            first_seen = get_entity_field(e, "first_seen", "timestamp", "created_at", "date", default="Recent")
            
            risk_score = e.get("risk_score", 0)
            try:
                risk_score = float(risk_score)
            except (ValueError, TypeError):
                risk_score = 0.0

            risk_label = "🔴 High" if risk_score > 0.7 else ("🟠 Medium" if risk_score > 0.3 else "🟢 Low")
            
            table_data.append({
                "Platform": platform_val,
                "Username / Handle": handle_val,
                "Entity ID": entity_id,
                "Risk Level": risk_label,
                "First Observed": first_seen
            })
        
        df_entities = pd.DataFrame(table_data)
        st.dataframe(df_entities, use_container_width=True)
    else:
        st.info("No entity data loaded in `data/entities.json`.")

# TAB 2: LIVE WEBSITE TRACKER WITH LOGOS
with tab2:
    st.subheader("Target Website Monitoring & Suspicious Activity Tracker")
    st.caption("Live monitoring of suspect web domains, server status, latency, and threat classifications.")
    
    demo_websites = [
        {"url": "https://telegram.org", "domain": "telegram.org", "Category": "Messaging App", "Threat Score": "Low Risk"},
        {"url": "http://darkmarket-sample.onion", "domain": "darkmarket-sample.onion", "Category": "Darknet Forum", "Threat Score": "High Risk"},
        {"url": "https://pastebin.com", "domain": "pastebin.com", "Category": "Text Repository", "Threat Score": "Medium Risk"},
        {"url": "https://instagram.com", "domain": "instagram.com", "Category": "Social Network", "Threat Score": "Low Risk"}
    ]
    
    new_url = st.text_input("➕ Add custom URL to live test:", placeholder="e.g. example.com")
    if new_url:
        clean_url = new_url if new_url.startswith(("http://", "https://")) else f"https://{new_url}"
        demo_websites.append({"url": clean_url, "domain": new_url, "Category": "Custom Input", "Threat Score": "Under Review"})
        
    if st.button("🔄 Perform Live Ping Test"):
        st.cache_data.clear()

    tracking_results = []
    with st.spinner("Pinging target websites..."):
        for site in demo_websites:
            url = site["url"]
            status, latency, activity = ping_website(url)
            tracking_results.append({
                "Logo": get_favicon_url(url),
                "Website Link": url,
                "Category": site["Category"],
                "Live Server Status": status,
                "Latency": latency,
                "Threat Assessment": site["Threat Score"],
                "Activity Status": activity
            })
            
    df_websites = pd.DataFrame(tracking_results)
    st.dataframe(
        df_websites,
        column_config={
            "Logo": st.column_config.ImageColumn("Logo", help="Site Favicon"),
            "Website Link": st.column_config.LinkColumn("Website Link", display_text=r"https?://(?:www\.)?([^/]+)")
        },
        use_container_width=True
    )

# TAB 3: VISUAL NETWORK GRAPH WITH ROBUST LINKING
with tab3:
    st.subheader("Visual Relationship Map")
    st.caption("Interactive graph showing how identities, accounts, and platforms are linked together.")
    
    if entities:
        net = Network(height="520px", width="100%", bgcolor="#0E1117", font_color="#FFFFFF")
        net.barnes_hut()
        
        # Track registered node IDs to prevent duplicates and broken links
        node_map = {}
        
        # Add entity nodes
        for e in entities:
            # Map node ID from any available key
            node_id = str(get_entity_field(e, "entity_id", "id", "handle", "username", "name", default="node_unknown"))
            label = str(get_entity_field(e, "handle", "username", "name", "alias", "entity_id", "id", default=node_id))
            
            risk = e.get("risk_score", 0.5)
            try:
                risk = float(risk)
            except (ValueError, TypeError):
                risk = 0.5
                
            color = "#EF4444" if risk > 0.7 else ("#F59E0B" if risk > 0.3 else "#22C55E")
            
            if node_id not in node_map:
                net.add_node(node_id, label=label, color=color, title=f"Handle: {label}\nID: {node_id}\nRisk Score: {risk}")
                node_map[node_id] = label
        
        # Add connecting links with multi-key lookup
        added_edges = 0
        for l in links:
            src = str(get_entity_field(l, "source", "source_id", "from", "src", "entity1", default=""))
            tgt = str(get_entity_field(l, "target", "target_id", "to", "dst", "entity2", default=""))
            relationship = str(get_entity_field(l, "type", "relationship", "label", "relation", default="connected"))
            
            # If target or source is missing in node_map, auto-create missing endpoint nodes
            if src and src not in node_map:
                net.add_node(src, label=src, color="#3B82F6", title=f"Derived Entity: {src}")
                node_map[src] = src
                
            if tgt and tgt not in node_map:
                net.add_node(tgt, label=tgt, color="#3B82F6", title=f"Derived Entity: {tgt}")
                node_map[tgt] = tgt
                
            if src and tgt:
                net.add_edge(src, tgt, title=relationship, label=relationship)
                added_edges += 1

        if added_edges == 0 and len(entities) > 1:
            st.warning("⚠️ `links.json` did not match entity IDs directly. Connecting entities sequentially for demonstration:")
            # Fallback sequence to display connected demo tree if links.json keys mismatch completely
            entity_keys = list(node_map.keys())
            for i in range(len(entity_keys) - 1):
                net.add_edge(entity_keys[i], entity_keys[i+1], title="associated_with", label="associated_with")
            
        graph_path = os.path.join(os.path.dirname(__file__), "network.html")
        net.save_graph(graph_path)
        
        with open(graph_path, "r", encoding="utf-8") as f:
            html_content = f.read()
        components.html(html_content, height=540)
    else:
        st.info("No network data available to generate graph.")

# TAB 4: THREAT SUMMARY
with tab4:
    st.subheader("Simple Executive Summary")
    st.markdown("""
    <div class="card-warning">
        <h4>⚠️ Key Findings Overview</h4>
        <ul>
            <li><b>Total Entities Identified:</b> Multiple aliases linked across Instagram, Telegram, and Darknet platforms.</li>
            <li><b>High Risk Connections:</b> Entities show correlation with known malicious forums.</li>
            <li><b>Website Activity:</b> Monitoring active domains for unexpected server downtime or content modifications.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)